// AWK OS 2 BIOS Boot Script
let bootTimer = null;
let countdownInterval = null;
let fPressed = false;
let biosOpen = false;

// Load performance optimization script
const perfScript = document.createElement('script');
perfScript.src = 'sys64/Performance.js';
document.head.appendChild(perfScript);

document.addEventListener('keyup', (e) => {
    if (e.key.toLowerCase() === 'f') {
        fPressed = false;
    }
});

function openBIOS() {
    if (biosOpen) return; // Prevent re-triggering if already open
    biosOpen = true;
    
    const menu = document.getElementById('bios-menu');
    const container = document.getElementById('bios-container');
    
    if (menu) menu.style.display = 'block'; 
    if (container) container.style.display = 'none';

    // Stop all timers
    clearInterval(countdownInterval);
    clearTimeout(bootTimer);
}

function closeBIOS() {
    biosOpen = false;
    
    const menu = document.getElementById('bios-menu');
    const container = document.getElementById('bios-container');
    
    if (menu) menu.style.display = 'none';
    if (container) container.style.display = 'block';

    startBootTimer();
}

function bootDesktop() {
    // Standard BIOS practice: clear intervals before navigating
    clearInterval(countdownInterval);
    window.location.href = '../AwkLoader/loader.html';
}

function resetBIOS() {
    if (confirm('Reset BIOS to Factory Defaults?')) {
        localStorage.clear();
        location.reload();
    }
}

function startBootTimer() {
    // Clear any existing intervals first to prevent "speed-up" bugs
    clearInterval(countdownInterval);
    
    let timeRemaining = 3;
    const timerDisplay = document.getElementById('countdown-timer');
    
    if (timerDisplay) {
        timerDisplay.innerText = timeRemaining;
    }

    countdownInterval = setInterval(() => {
        timeRemaining--;
        
        if (timerDisplay) {
            timerDisplay.innerText = timeRemaining;
        }

        if (timeRemaining <= 0) {
            clearInterval(countdownInterval);
            bootDesktop();
        }
    }, 1000);
}

// System info detection
document.addEventListener('DOMContentLoaded', () => {
    const memoryDisplay = document.getElementById('total-memory');
    if (memoryDisplay) {
        // navigator.deviceMemory returns RAM in GB
        if (navigator.deviceMemory) {
            memoryDisplay.innerText = navigator.deviceMemory + ' GB';
        } else {
            memoryDisplay.innerText = '8 GB (Estimated)';
        }
    }
    
    startBootTimer();
});

const kernelDisplay = document.getElementById('kernel-version');
if (kernelDisplay) {
    kernelDisplay.innerText = "1.0.0 AwkKernal";
}